# Gradle Wrapper JAR installieren

Die Datei `gradle/wrapper/gradle-wrapper.jar` muss einmalig heruntergeladen werden.

## Option A – Automatisch (empfohlen)

In Android Studio:
1. Projekt öffnen (File → Open → SchützenTracker Ordner)
2. Android Studio erkennt den fehlenden Wrapper automatisch
3. Klicke auf "OK" wenn gefragt wird ob der Wrapper erstellt werden soll
4. FERTIG ✓

## Option B – Manuell (Windows)

Öffne PowerShell im Projekt-Ordner und führe aus:
```powershell
Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-8.7-bin.zip" -OutFile gradle.zip
```

Oder lade die JAR direkt herunter:
https://github.com/gradle/gradle/raw/v8.7.0/gradle/wrapper/gradle-wrapper.jar
→ Speichern unter: gradle/wrapper/gradle-wrapper.jar

## Option C – Via Gradle (falls Gradle installiert ist)

```bash
gradle wrapper --gradle-version 8.7
```
