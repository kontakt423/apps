package com.schuetzentracker.data.database.dao

import androidx.room.*
import com.schuetzentracker.data.database.entities.*
import kotlinx.coroutines.flow.Flow

// ────────────────────────────────────────────────
// DISCIPLINE DAO
// ────────────────────────────────────────────────

@Dao
interface DisciplineDao {

    @Query("SELECT * FROM disciplines ORDER BY sortOrder ASC, name ASC")
    fun getAll(): Flow<List<DisciplineEntity>>

    @Query("SELECT * FROM disciplines WHERE id = :id")
    suspend fun getById(id: Long): DisciplineEntity?

    @Query("SELECT * FROM disciplines WHERE isCompetitionCapable = 1 ORDER BY name ASC")
    fun getCompetitionCapable(): Flow<List<DisciplineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(discipline: DisciplineEntity): Long

    @Update
    suspend fun update(discipline: DisciplineEntity)

    @Delete
    suspend fun delete(discipline: DisciplineEntity)

    @Query("DELETE FROM disciplines WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT COUNT(*) FROM disciplines")
    suspend fun count(): Int
}

// ────────────────────────────────────────────────
// TRAINING SESSION DAO
// ────────────────────────────────────────────────

@Dao
interface TrainingSessionDao {

    @Transaction
    @Query("SELECT * FROM training_sessions ORDER BY dateTimestamp DESC")
    fun getAllWithSeries(): Flow<List<SessionWithSeries>>

    @Transaction
    @Query("SELECT * FROM training_sessions WHERE disciplineId = :disciplineId ORDER BY dateTimestamp DESC")
    fun getByDiscipline(disciplineId: Long): Flow<List<SessionWithSeries>>

    @Transaction
    @Query("SELECT * FROM training_sessions WHERE mode IN (:modes) ORDER BY dateTimestamp DESC")
    fun getByModes(modes: List<String>): Flow<List<SessionWithSeries>>

    @Transaction
    @Query("SELECT * FROM training_sessions WHERE id = :id")
    suspend fun getById(id: Long): SessionWithSeries?

    @Query("SELECT * FROM training_sessions ORDER BY dateTimestamp DESC LIMIT :limit")
    fun getRecent(limit: Int = 5): Flow<List<TrainingSessionEntity>>

    @Query("SELECT MAX(totalRings) FROM training_sessions WHERE disciplineId = :disciplineId")
    fun getPersonalBest(disciplineId: Long): Flow<Int?>

    @Query("SELECT AVG(CAST(totalRings AS FLOAT)) FROM training_sessions WHERE disciplineId = :disciplineId AND dateTimestamp > :since")
    fun getAverageRings(disciplineId: Long, since: Long): Flow<Double?>

    @Query("SELECT COUNT(*) FROM training_sessions")
    fun getTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM training_sessions WHERE mode IN ('COMPETITION','QUALIFICATION')")
    fun getCompetitionCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: TrainingSessionEntity): Long

    @Update
    suspend fun update(session: TrainingSessionEntity)

    @Query("DELETE FROM training_sessions WHERE id = :id")
    suspend fun deleteById(id: Long)
}

// ────────────────────────────────────────────────
// SERIES DAO
// ────────────────────────────────────────────────

@Dao
interface SeriesDao {

    @Transaction
    @Query("SELECT * FROM series WHERE sessionId = :sessionId ORDER BY number ASC")
    fun getForSession(sessionId: Long): Flow<List<SeriesWithShots>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(series: SeriesEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(series: List<SeriesEntity>): List<Long>

    @Update
    suspend fun update(series: SeriesEntity)

    @Query("UPDATE series SET analysisJson = :json WHERE id = :id")
    suspend fun updateAnalysis(id: Long, json: String)
}

// ────────────────────────────────────────────────
// SHOT DAO
// ────────────────────────────────────────────────

@Dao
interface ShotDao {

    @Query("SELECT * FROM shots WHERE seriesId = :seriesId ORDER BY number ASC")
    fun getForSeries(seriesId: Long): Flow<List<ShotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(shot: ShotEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(shots: List<ShotEntity>)
}

// ────────────────────────────────────────────────
// GOAL DAO
// ────────────────────────────────────────────────

@Dao
interface TrainingGoalDao {

    @Query("SELECT * FROM training_goals ORDER BY isAchieved ASC, deadlineTimestamp ASC")
    fun getAll(): Flow<List<TrainingGoalEntity>>

    @Query("SELECT * FROM training_goals WHERE disciplineId = :disciplineId AND isAchieved = 0")
    fun getActiveForDiscipline(disciplineId: Long): Flow<List<TrainingGoalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(goal: TrainingGoalEntity): Long

    @Update
    suspend fun update(goal: TrainingGoalEntity)

    @Query("UPDATE training_goals SET isAchieved = 1, achievedTimestamp = :timestamp WHERE id = :id")
    suspend fun markAchieved(id: Long, timestamp: Long)

    @Delete
    suspend fun delete(goal: TrainingGoalEntity)
}

// ────────────────────────────────────────────────
// ACHIEVEMENT DAO
// ────────────────────────────────────────────────

@Dao
interface AchievementDao {

    @Query("SELECT * FROM achievements")
    fun getAll(): Flow<List<AchievementEntity>>

    @Query("SELECT * FROM achievements WHERE id = :id")
    suspend fun getById(id: String): AchievementEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun unlock(achievement: AchievementEntity)
}

// ────────────────────────────────────────────────
// STATISTICS DAO
// ────────────────────────────────────────────────

@Dao
interface StatisticsDao {

    @Query("""
        SELECT (dateTimestamp / (7 * 24 * 3600)) AS weekNumber,
               AVG(CAST(totalRings AS FLOAT)) AS avgRings,
               COUNT(*) AS sessionCount
        FROM training_sessions
        WHERE disciplineId = :disciplineId AND dateTimestamp > :since
        GROUP BY weekNumber
        ORDER BY weekNumber ASC
    """)
    fun getWeeklyStats(disciplineId: Long, since: Long): Flow<List<WeeklyStatsRow>>

    @Query("""
        SELECT strftime('%Y-%m', datetime(dateTimestamp, 'unixepoch')) AS month,
               AVG(CAST(totalRings AS FLOAT)) AS avgRings,
               MAX(totalRings) AS bestRings,
               COUNT(*) AS sessionCount
        FROM training_sessions
        WHERE disciplineId = :disciplineId
        GROUP BY month
        ORDER BY month DESC
        LIMIT 12
    """)
    fun getMonthlyStats(disciplineId: Long): Flow<List<MonthlyStatsRow>>

    @Query("""
        SELECT fatigue, AVG(CAST(totalRings AS FLOAT)) AS avgRings
        FROM training_sessions
        WHERE disciplineId = :disciplineId
        GROUP BY fatigue
    """)
    fun getFatigueCorrelation(disciplineId: Long): Flow<List<CorrelationRow>>

    @Query("""
        SELECT weather, AVG(CAST(totalRings AS FLOAT)) AS avgRings
        FROM training_sessions
        WHERE disciplineId = :disciplineId
        GROUP BY weather
    """)
    fun getWeatherCorrelation(disciplineId: Long): Flow<List<WeatherCorrelationRow>>

    @Query("""
        SELECT DISTINCT date(datetime(dateTimestamp, 'unixepoch')) AS day
        FROM training_sessions
        ORDER BY day DESC
    """)
    fun getTrainingDays(): Flow<List<String>>

    @Query("""
        SELECT mode, COUNT(*) AS count, AVG(CAST(totalRings AS FLOAT)) AS avgRings
        FROM training_sessions
        GROUP BY mode
    """)
    fun getStatsByMode(): Flow<List<ModeStatsRow>>
}

// ── Ergebnis-Klassen für komplexe Queries ─────────

data class WeeklyStatsRow(
    val weekNumber: Long,
    val avgRings: Double,
    val sessionCount: Int
)

data class MonthlyStatsRow(
    val month: String,
    val avgRings: Double,
    val bestRings: Int,
    val sessionCount: Int
)

data class CorrelationRow(
    val fatigue: String,
    val avgRings: Double
)

data class WeatherCorrelationRow(
    val weather: String,
    val avgRings: Double
)

data class ModeStatsRow(
    val mode: String,
    val count: Int,
    val avgRings: Double
)
